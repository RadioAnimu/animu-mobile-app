import type { PlayerErrorCode, PlayerErrorInfo } from './types.js';
/**
 * Every error the library throws or reports. Native details are preserved:
 * `platformDomain` / `platformCode` / `httpStatus` / `cause` (the full native
 * error chain) — never just "code=-11800".
 */
export declare class PlayerError extends Error {
    readonly code: PlayerErrorCode;
    /** Retrying (reconnect, or calling `play()` again) can succeed. */
    readonly recoverable: boolean;
    readonly platform?: 'ios' | 'android';
    readonly httpStatus?: number;
    readonly platformDomain?: string;
    readonly platformCode?: number;
    /** Native error chain, e.g. `NSURLErrorDomain(-1009): The Internet connection appears to be offline.` */
    readonly nativeCause?: string;
    constructor(info: PlayerErrorInfo);
    toJSON(): PlayerErrorInfo;
}
export declare function isPlayerError(value: unknown): value is PlayerError;
/** Normalizes a native promise rejection (or anything thrown) into a PlayerError. */
export declare function toPlayerError(value: unknown): PlayerError;
//# sourceMappingURL=errors.d.ts.map