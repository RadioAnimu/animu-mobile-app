import type { Player } from './Player.js';
import type { MediaMetadata, PlaybackState, PlayerEvent, PlayerEventMap, PlayerStatus, Progress } from './types.js';
/** The player's status; re-renders on every change. */
export declare function usePlayerStatus(player: Player): PlayerStatus;
/** Just the playback state (re-renders only when it changes). */
export declare function usePlaybackState(player: Player): PlaybackState;
/** The latest stream metadata (ICY / ID3 / timed metadata). */
export declare function useStreamMetadata(player: Player): MediaMetadata | null;
/**
 * Position/duration/buffer, polled from native every `intervalMs` while the
 * app is in the foreground. No progress events cross the bridge: the reading
 * is a synchronous JSI call against a native clock, so it is correct even
 * right after JS was frozen in the background.
 */
export declare function useProgress(player: Player, intervalMs?: number): Progress;
/** Subscribes to a player event for the component's lifetime. */
export declare function usePlayerEvent<E extends PlayerEvent>(player: Player, event: E, handler: PlayerEventMap[E]): void;
//# sourceMappingURL=hooks.d.ts.map