import type { AudioSamplingOptions, DiagnosticEntry, LoadOptions, MediaMetadata, NowPlayingMetadata, PlaybackState, PlayerEvent, PlayerEventMap, PlayerOptions, PlayerStatus, Progress, SourceInput } from './types.js';
/** Validates and normalizes what apps pass to `load()`. Exported for tests. */
export declare function normalizeSource(input: SourceInput): Record<string, unknown>;
/** Exported for tests. */
export declare function normalizeNowPlaying(metadata: NowPlayingMetadata): Record<string, unknown>;
/**
 * An audio player. Playback, recovery, interruptions and the lock screen are
 * owned by native code; this object sends commands and mirrors native state.
 *
 * ```ts
 * const player = new Player();
 * await player.load('https://radio.example.com/stream');
 * await player.play();
 * ```
 *
 * Players live until `release()` — unmounting a component does not stop audio.
 */
export declare class Player {
    /** Native player id (stable for the player's lifetime). */
    readonly id: string;
    private _status;
    private _metadata;
    private readonly listeners;
    private released;
    constructor(options?: PlayerOptions);
    /** Last known status (updated by events and command results; cheap, stable identity). */
    get status(): PlayerStatus;
    get state(): PlaybackState;
    /** Whether playback is wanted (what a play/pause button should show). */
    get playWhenReady(): boolean;
    /** Latest stream metadata (ICY / ID3 / timed metadata), or `null`. */
    get metadata(): MediaMetadata | null;
    /** Reads the authoritative status from native now and applies it if newer. */
    refresh(): PlayerStatus;
    /**
     * Current position/duration/buffer, read synchronously from native and
     * extrapolated to "now". Cheap enough to call every animation frame.
     */
    getProgress(): Progress;
    /**
     * Opens a source. Resolves once it is ready to play (or when a later `load`
     * replaced it); rejects if it cannot be opened. Keeps the current play
     * intent unless `autoplay` is given — a playing player switches sources
     * seamlessly.
     */
    load(source: SourceInput, options?: LoadOptions): Promise<void>;
    /** Starts or resumes playback (re-opens live streams at the live edge when needed). */
    play(): Promise<void>;
    pause(): Promise<void>;
    /** Pauses when playback is wanted, plays otherwise. */
    toggle(): Promise<void>;
    /** Stops and releases network/decoder resources; the source stays loaded. */
    stop(): Promise<void>;
    /** Unloads the source (back to `idle`). */
    reset(): Promise<void>;
    /** Seconds. Rejects with `NOT_SEEKABLE` for live streams. */
    seekTo(position: number): Promise<void>;
    /** 0…1 (clamped). Independent of `muted`. */
    setVolume(volume: number): Promise<void>;
    setMuted(muted: boolean): Promise<void>;
    setRate(rate: number): Promise<void>;
    /**
     * Overrides what the lock screen shows (until the next `load`). Each call
     * replaces the previous overrides; pass `{}` to fall back to stream/source
     * metadata.
     */
    updateNowPlaying(metadata: NowPlayingMetadata): Promise<void>;
    /** Stops playback and frees every native resource. The player is unusable afterwards. */
    release(): Promise<void>;
    get isReleased(): boolean;
    /** Streams engine traces as `diagnostic` events and to the native log. */
    setDiagnosticsEnabled(enabled: boolean): void;
    /**
     * Streams decoded audio as `audioSample` events (for oscilloscopes and
     * spectrum views). Off by default; costs nothing while off. Returns whether
     * the platform supports it.
     */
    setAudioSampling(options: AudioSamplingOptions): boolean;
    /** The last ~300 engine traces (kept natively even while diagnostics are off). */
    getDiagnostics(): DiagnosticEntry[];
    /** Subscribes; returns the unsubscribe function. */
    on<E extends PlayerEvent>(event: E, listener: PlayerEventMap[E]): () => void;
    /** Number of listeners (useful to verify cleanup). */
    listenerCount(event?: PlayerEvent): number;
    private emit;
    /** @internal Native event entry point. */
    _handleEvent(raw: object): void;
    /** Applies a status snapshot unless an equal-or-newer one was already applied. */
    private apply;
    private ensureAlive;
    private run;
}
/** @internal Test hook. */
export declare function _livePlayerCount(): number;
//# sourceMappingURL=Player.d.ts.map